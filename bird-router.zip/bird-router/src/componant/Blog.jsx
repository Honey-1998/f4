import React from 'react'

function Blog() {
  return (
    <div>Blog Artical</div>
  )
}

export default Blog