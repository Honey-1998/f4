import React from 'react'

function Contact() {
  return (
    <div>Contact Me</div>
  )
}

export default Contact