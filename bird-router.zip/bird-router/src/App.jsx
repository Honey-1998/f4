import React from 'react'
import './App.css'
import { Route , Routes } from 'react-router-dom'
import Nav from './componant/Nav'
import Home from './componant/Home'
import Blog from './componant/Blog'
import Contact from './componant/Contact'

function App() {
  

  return (
    <>
    <div className='main'>
      {/* //nav is static */}
    <Nav/>
    {/* //apply routing  */}
    <Routes>
     
          <Route path='/' element={<Home/>} />
          <Route path='/blog' element={<Blog/>} />
          <Route path='/contact' element={<Contact/>} />
    </Routes>
    </div>
      
    </>
  )
}

export default App
